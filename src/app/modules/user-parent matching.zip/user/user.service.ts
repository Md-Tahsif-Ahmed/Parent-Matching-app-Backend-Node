import { USER_ROLES } from "../../../enums/user";
import { IUser } from "./user.interface";
import { JwtPayload } from 'jsonwebtoken';
import { User } from "./user.model";
import { StatusCodes } from "http-status-codes";
import ApiError from "../../../errors/ApiErrors";
import generateOTP from "../../../util/generateOTP";
import { emailTemplate } from "../../../shared/emailTemplate";
import { emailHelper } from "../../../helpers/emailHelper";
import unlinkFile from "../../../shared/unlinkFile";
import { Profile } from "../profile/profile.model";
 
const createAdminToDB = async (payload: Partial<IUser>): Promise<IUser> => {
  // ইমেইল কনফ্লিক্ট চেক
  const isExistAdmin = await User.findOne({ email: payload.email });
  if (isExistAdmin) {
    throw new ApiError(StatusCodes.CONFLICT, "This Email already taken");
  }

  // name fallback
  if (!payload.name && (payload.firstName || payload.lastName)) {
    payload.name = [payload.firstName, payload.lastName].filter(Boolean).join(' ').trim();
  }

  const created = await User.create({ ...payload, role: payload.role ?? USER_ROLES.ADMIN });
  if (!created) throw new ApiError(StatusCodes.BAD_REQUEST, 'Failed to create Admin');

  // verify
  await User.findByIdAndUpdate(created._id, { verified: true }, { new: true });

  // চাইলে খালি প্রোফাইল বানিয়ে রাখতে পারো
  await Profile.updateOne(
    { user: created._id },
    { $setOnInsert: { user: created._id } },
    { upsert: true }
  );

  return created;
};

const createUserToDB = async (payload: Partial<IUser>): Promise<IUser> => {
  // name fallback
  if (!payload.name && (payload.firstName || payload.lastName)) {
    payload.name = [payload.firstName, payload.lastName].filter(Boolean).join(' ').trim();
  }

  const user = await User.create(payload);
  if (!user) throw new ApiError(StatusCodes.BAD_REQUEST, 'Failed to create user');

  // খালি Profile upsert (optional but recommended)
  await Profile.updateOne(
    { user: user._id },
    { $setOnInsert: { user: user._id } },
    { upsert: true }
  );

  // send OTP email
  const otp = generateOTP();
  if (!user.email) {
    throw new ApiError(StatusCodes.BAD_REQUEST, 'User email is required to send OTP');
  }
  const tpl = emailTemplate.createAccount({ name: user.name ?? '', otp, email: user.email! });
  emailHelper.sendEmail(tpl);

  // auth props save
  const authentication = {
    oneTimeCode: otp,
    expireAt: new Date(Date.now() + 3 * 60000),
    isResetPassword: false,
  };
  await User.findByIdAndUpdate(user._id, { $set: { authentication } });

  return user;
};

const getUserProfileFromDB = async (user: JwtPayload): Promise<Partial<IUser>> => {
  const isExistUser: any = await User.isExistUserById(user.id); // populate('profile') ভিতরে হয়
  if (!isExistUser) throw new ApiError(StatusCodes.BAD_REQUEST, "User doesn't exist!");
  return isExistUser;
};

// ⬇️ গুরুত্বপূর্ণ: এখন দুইটা আপডেট—User + Profile
const updateProfileToDB = async (
  user: JwtPayload,
  userUpdate: Partial<IUser>,
  profileUpdate: any
): Promise<any> => {
  const { id } = user;
  const isExistUser: any = await User.isExistUserById(id);
  if (!isExistUser) {
    throw new ApiError(StatusCodes.BAD_REQUEST, "User doesn't exist!");
  }

  // profile image বদলালে আগের ফাইল unlink (Profile থেকে)
  if (profileUpdate?.avatar) {
    const prevProfile = await Profile.findOne({ user: id }).lean() as Partial<{ avatar?: string } | null>;
    if (prevProfile && prevProfile.avatar) {
      unlinkFile(prevProfile.avatar);
    }
  }

  // User update (runValidators সহ)
  const updatedUser = await User.findOneAndUpdate(
    { _id: id },
    userUpdate,
    { new: true, runValidators: true }
  );

  // Profile upsert/update
  if (profileUpdate && Object.keys(profileUpdate).length > 0) {
    await Profile.updateOne(
      { user: id },
      { $set: profileUpdate, $setOnInsert: { user: id } },
      { upsert: true }
    );
  }

  // পড়ার সময় populate দেই যাতে আপডেটেড প্রোফাইলও আসে
  const withProfile = await User.findById(id).populate('profile').lean();

  return withProfile;
};

export const UserService = {
  createUserToDB,
  getUserProfileFromDB,
  updateProfileToDB,
  createAdminToDB,
};
