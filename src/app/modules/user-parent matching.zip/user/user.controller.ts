import { NextFunction, Request, Response } from 'express';
import { StatusCodes } from 'http-status-codes';
import { UserService } from './user.service';
import catchAsync from '../../../shared/catchAsync';
import sendResponse from '../../../shared/sendResponse';

// register user
const createUser = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  // body থেকে dob string এলে Date বানিয়ে নিই
  const { dob, firstName, lastName, name, ...rest } = req.body;

  const payload: any = {
    ...rest,
    dob: dob ? new Date(dob) : undefined,
  };

  // name auto (controller layer এও safe-guard)
  if (!name && (firstName || lastName)) {
    payload.name = [firstName, lastName].filter(Boolean).join(' ').trim();
  } else {
    payload.name = name;
  }
  payload.firstName = firstName;
  payload.lastName  = lastName;

  await UserService.createUserToDB(payload);

  sendResponse(res, {
    success: true,
    statusCode: StatusCodes.OK,
    message:
      'Your account has been successfully created. Verify Your Email By OTP. Check your email',
  });
});

// register admin
const createAdmin = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  const { dob, ...rest } = req.body;
  const payload = { ...rest, dob: dob ? new Date(dob) : undefined };

  const result = await UserService.createAdminToDB(payload);

  sendResponse(res, {
    success: true,
    statusCode: StatusCodes.OK,
    message: 'Admin created successfully',
    data: result,
  });
});

// retrieved user profile
const getUserProfile = catchAsync(async (req: Request, res: Response) => {
  const result = await UserService.getUserProfileFromDB(req.user);
  sendResponse(res, {
    success: true,
    statusCode: StatusCodes.OK,
    message: 'Profile data retrieved successfully',
    data: result,
  });
});

// update profile (User + Profile আলাদা আপডেট)
const updateProfile = catchAsync(async (req: Request, res: Response, _next: NextFunction) => {
  // image থাকলে ফাইল পাথ তৈরি
  let avatar: string | undefined;
  if (req.files && 'image' in req.files && req.files.image[0]) {
    avatar = `/images/${req.files.image[0].filename}`;
  }

  // user-update fields
  const { firstName, lastName, name, dob, ...rest } = req.body;

  const userUpdate: any = {
    ...rest,
    firstName,
    lastName,
    // name না দিলে first+last থেকে compose হবে service/model হুকে
    name,
    dob: dob ? new Date(dob) : undefined,
  };

  const profileUpdate: any = {};
  if (avatar) profileUpdate.avatar = avatar; // ধরে নিলাম Profile schema তে avatar/string আছে

  const result = await UserService.updateProfileToDB(req.user, userUpdate, profileUpdate);

  sendResponse(res, {
    success: true,
    statusCode: StatusCodes.OK,
    message: 'Profile updated successfully',
    data: result,
  });
});

export const UserController = {
  createUser,
  createAdmin,
  getUserProfile,
  updateProfile,
};
